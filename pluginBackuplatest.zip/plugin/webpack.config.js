const path = require('path');

module.exports = {
    entry: './toolbar.js', // Entry point for your JS
    output: {
        filename: 'YourInclusion.js', // Output JS file
        path: path.resolve(__dirname, 'dist'), // Output directory
        library: 'YourInclusion', // Export as a global variable
        libraryTarget: 'umd', // Universal Module Definition
    },
    module: {
        rules: [
            {
                test: /\.css$/, // Match CSS files
                use: ['style-loader', 'css-loader'], // Use style-loader and css-loader
            },
        ],
    },
    // mode: 'production',
    mode: 'development',
};

